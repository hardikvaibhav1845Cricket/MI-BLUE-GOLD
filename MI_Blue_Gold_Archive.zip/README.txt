MI BLUE & GOLD ARCHIVE
=======================

Files:
- index.html  -> complete responsive website
- robots.txt  -> replace example.com with your real domain
- sitemap.xml -> replace example.com with your real domain

Before publishing:
1. Replace https://example.com/ in index.html, robots.txt and sitemap.xml with your real URL.
2. Add a favicon and licensed/owned images if you want them.
3. Verify current stats after each IPL season.
4. Do not present this as the official Mumbai Indians website.
5. Submit the sitemap in Google Search Console after deployment.
